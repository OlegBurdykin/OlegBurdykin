from captcha.fields import CaptchaField
from django import forms
from django.core.exceptions import ValidationError
from django.core.validators import MinLengthValidator, MaxLengthValidator
from django.utils.deconstruct import deconstructible

from .models import Category, Husband, Women


@deconstructible
class RussianValidator:
    ALLOWED_CHARS = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЬЫЪЭЮЯабвгдеёжзийклмнопрстуфхцчшщьыъэюя0123456789- "
    code = "russian"

    def __init__(self, message=None):
        self.message = message if message else "Должны использоваться только русские буквы, дефис и пробел"

    def __call__(self, value):
        if not set(value) <= set(self.ALLOWED_CHARS):
            raise ValidationError(self.message, code=self.code)


class AddPostForm(forms.ModelForm):
    cat = forms.ModelChoiceField(queryset=Category.objects.all(), empty_label="Категория не выбрана", label="Категория")
    husband = forms.ModelChoiceField(queryset=Husband.objects.all(), required=False, empty_label="Не замужем", label="Муж")

    class Meta:
        model = Women
        fields = ["title", "slug", "content", "photo", "is_published", "cat", "husband", "tags"]
        widgets = {
            "title": forms.TextInput(attrs={"class": "text-input"}),
            "content": forms.Textarea(attrs={"cols": 50, "rows": 5}),
        }
        labels = {"slug": "URL"}

    def clean_title(self):
        title = self.cleaned_data["title"]
        if len(title) > 50:
            raise ValidationError("Длина превышает 50 символов")
        return title


class UploadFileForm(forms.Form):
    file = forms.ImageField(label="Файл")


class ContactForm(forms.Form):
    username = forms.CharField(max_length=255, label="Имя пользователя")
    email = forms.EmailField(label="E-mail")
    content = forms.CharField(label="Суть обращения", widget=forms.Textarea(attrs={"cols": 50, "rows": 5}))

    def __init__(self, *args, **kwargs):
        user = kwargs.pop("user")  # удаляем ранее созданный во вьюхе ключ "user", т.к. с ним __init__ не сработает
        super().__init__(*args, **kwargs)
        if user.is_authenticated:
            self.fields["username"].initial = user.username
            self.fields["username"].disabled = True
            self.fields["email"].initial = user.email
            self.fields["email"].disabled = True
        else:
            self.fields["captcha"] = CaptchaField()
