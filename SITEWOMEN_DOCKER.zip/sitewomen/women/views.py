from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.paginator import Paginator
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, HttpResponseNotFound, Http404
from django.views import View
from django.views.generic import TemplateView, ListView, DetailView, FormView, CreateView, UpdateView, DeleteView
from django.urls import reverse, reverse_lazy
from django.template.loader import render_to_string
from django.template.defaultfilters import slugify

from .models import Women, Category, TagPost, UploadModel
from .forms import AddPostForm, UploadFileForm, ContactForm
from .utils import DataMixin
from django.core.cache import cache


class WomenHome(DataMixin, ListView):
    # model = Women  # по умолчанию будет выдавать вообще все статьи, даже в статусе "черновик"
    template_name = "women/index.html"
    context_object_name = "posts"  # имя прописанное в шаблоне index.html
    title_page = "Главная страница"
    cat_selected = 0

    def get_queryset(self):
        """возвращает нужную нам выборку из модели по определенному критерию"""
        women_list = cache.get("women_posts")
        if not women_list:
            women_list = Women.published.all().select_related("cat")
            cache.set("women_posts", women_list, 60)
        return women_list

    def get_context_data(self, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        return super().get_mixin_context(context)


@login_required
def about(request):
    contact_list = Women.published.all()
    paginator = Paginator(contact_list, 3)

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(request, 'women/about.html', {'page_obj': page_obj})


class AddPage(PermissionRequiredMixin, DataMixin, CreateView):
    form_class = AddPostForm
    # model = Women
    # fields = ['title', 'slug', 'content', 'is_published', 'cat']  # или '__all__' для вообще всех полей
    template_name = 'women/addpage.html'
    title_page = 'Добавление статьи'
    success_url = reverse_lazy('home')  # по этому url мы отправимся после успешной обработки формы
    permission_required = 'women.add_women'  # 'appName.permissionName_tableName'

    def form_valid(self, form):
        w = form.save(commit=False)
        w.author = self.request.user
        return super().form_valid(form)

    def get_context_data(self, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        return super().get_mixin_context(context)


class UpdatePage(PermissionRequiredMixin, DataMixin, UpdateView):
    model = Women
    fields = ['title', 'content', 'photo', 'is_published', 'cat']
    template_name = 'women/addpage.html'
    title_page = 'Редактирование статьи'
    success_url = reverse_lazy('home')  # по этому url мы отправимся после успешной обработки формы
    permission_required = 'women.change_women' # 'appName.permissionName_tableName'


class DeletePage(DataMixin, DeleteView):
    model = Women
    success_url = reverse_lazy('home')
    template_name = 'women/women_confirm_delete.html'
    title_page = 'Удаление статьи'


class ContactFormView(DataMixin, FormView):
    form_class = ContactForm
    template_name = 'women/contact.html'
    success_url = reverse_lazy('home')
    title_page = 'Обратная связь'

    def form_valid(self, form):
        print(form.cleaned_data)
        return super().form_valid(form)

    def get_context_data(self, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        return super().get_mixin_context(context)

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["user"] = self.request.user
        return kwargs


def login(request):
    return HttpResponse("Авторизация")


class ShowPost(DataMixin, DetailView):
    # model = Women
    template_name = "women/post.html"
    slug_url_kwarg = "post_slug"
    context_object_name = "post"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        return super().get_mixin_context(context, title=context["post"].title)

    def get_object(self, queryset=None):
        return get_object_or_404(Women.published, slug=self.kwargs[self.slug_url_kwarg])


def page_not_found(request, exception):
    return HttpResponseNotFound("<h1>Страница не найдена</h1>")


class WomenCategory(DataMixin, ListView):
    template_name = "women/index.html"
    context_object_name = "posts"
    allow_empty = False  # чтобы при неправильной категории была ошибка 404

    def get_queryset(self):
        return Women.published.filter(cat__slug=self.kwargs["cat_slug"]).select_related("cat")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        cat = context["posts"][0].cat
        return super().get_mixin_context(context,
                                         title="Категория -" + cat.name,
                                         cat_selected=cat.pk)


class TagPostList(DataMixin, ListView):
    template_name = "women/index.html"
    context_object_name = "posts"
    allow_empty = False

    def get_queryset(self):
        return Women.published.filter(tags__slug=self.kwargs["tag_slug"]).select_related("cat")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # tag = TagPost.objects.get(slug=self.kwargs["tag_slug"])  # для создания имени вкладки
        tag = get_object_or_404(TagPost, slug=self.kwargs["tag_slug"]) # для создания имени вкладки
        return super().get_mixin_context(context,
                                         title="Тэг: " + tag.tag)
