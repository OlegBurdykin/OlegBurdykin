from django import template
from django.db.models import Count

import women.views as views
from women.models import Category, TagPost


register = template.Library()  # для регистрации пользовательских тэгов


# @register.simple_tag
# def get_menu():
#     return menu


@register.inclusion_tag('women/list_categories.html')
def show_categories(cat_selected=0):
    categories = Category.objects.annotate(total=Count("posts")).filter(total__gt=0)

    return {
        "categories": categories,
        "cat_selected": cat_selected,
    }


@register.inclusion_tag('women/list_tags.html')
def show_all_tags():
    tags = TagPost.objects.annotate(total=Count("tags")).filter(total__gt=0)  # только теги, с которыми существует хотя бы 1 пост

    return {"tags": tags}

