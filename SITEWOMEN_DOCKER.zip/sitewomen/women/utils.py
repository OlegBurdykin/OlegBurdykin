class DataMixin:
    paginate_by = 4
    title_page = None
    cat_selected = None
    # extra_context = {}

    # def __init__(self):
    #     if self.title_page:
    #         self.extra_context['title'] = self.title_page
    #
    #     if self.cat_selected is not None:
    #         self.extra_context['cat_selected'] = self.cat_selected
    #
    #     if 'menu' not in self.extra_context:
    #         self.extra_context['menu'] = menu

    def get_mixin_context(self, context: dict, **kwargs):
        if self.title_page is not None:
            context['title'] = self.title_page

        if self.cat_selected is not None:
            context['cat_selected'] = self.cat_selected

        if 'paginator' in context:
            context["elided_range"] = context["paginator"].get_elided_page_range(context['page_obj'].number,
                                                                                 on_each_side=1,
                                                                                 on_ends=1)
        context.update(kwargs)
        return context
