from http import HTTPStatus

from django.test import TestCase
from django.urls import reverse

from women.models import Women
from women.utils import DataMixin


class GetPagesTestCase(TestCase):
    fixtures = ["women_women.json", "women_category.json", "women_husband.json", "women_tagpost.json"]

    def setUp(self):
        pass

    def test_mainpage(self):
        path = reverse("home")
        response = self.client.get(path)
        self.assertEqual(response.status_code, HTTPStatus.OK)
        self.assertTemplateUsed(response, "women/index.html")
        self.assertEqual(response.context_data["title"], "Главная страница")

    def test_redirect_addpage(self):
        "проверка правильности перенаправления неавторизованных пользователей, пытающихся зайти на /addpage"
        path = reverse("add_page")
        redirect_url = reverse("users:login") + "?next=" + path
        response = self.client.get(path)
        self.assertEqual(response.status_code, HTTPStatus.FOUND)
        self.assertRedirects(response, redirect_url)

    def test_data_mainpage(self):
        w = Women.published.all().select_related("cat")
        path = reverse("home")
        response = self.client.get(path)
        paginate_limit = DataMixin.paginate_by
        self.assertQuerySetEqual(response.context_data["posts"], w[:paginate_limit])

    def test_mainpage_pagination(self):
        path = reverse("home")
        page = 2
        paginate_limit = DataMixin.paginate_by
        response = self.client.get(path + f"?page={page}")
        w = Women.published.all().select_related("cat")[(page-1)*paginate_limit : page*paginate_limit]
        self.assertQuerySetEqual(response.context_data["posts"], w)

    def test_post_content(self):
        w = Women.published.get(pk=1)
        path = reverse("post", args=[w.slug])
        response = self.client.get(path)
        self.assertQuerySetEqual(w.content, response.context_data["post"].content)

    def tearDown(self):
        pass