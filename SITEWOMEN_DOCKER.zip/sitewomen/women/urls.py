from django.conf.urls.static import static

from sitewomen import settings
from . import views
from . import converters
from django.urls import path, re_path, register_converter
from django.views.decorators.cache import cache_page

register_converter(converters.FourDigitYearConverter, "year4")  # регистрация конвертера

urlpatterns = [
    path('', views.WomenHome.as_view(), name='home'),  # http://127.0.0.1:8000/
    path('about/', views.about, name='about'),  # http://127.0.0.1:8000/about/
    path('addpage/', views.AddPage.as_view(), name='add_page'),
    path('contact/', views.ContactFormView.as_view(), name='contact'),
    path('login/', views.login, name='login'),
    path('post/<slug:post_slug>/', views.ShowPost.as_view(), name='post'),  # http://127.0.0.1:8000/post/1/
    path('category/<slug:cat_slug>/', views.WomenCategory.as_view(), name='category'),
    path('tags/<slug:tag_slug>/', views.TagPostList.as_view(), name='tag'),
    path('edit/<slug:slug>/', views.UpdatePage.as_view(), name='edit_page'),
    path('delete/<slug:slug>/', views.DeletePage.as_view(), name='delete_page'),
]

# if settings.DEBUG:
#     urlpatterns += static(settings.MEDIA_URL, settings.MEDIA_ROOT)