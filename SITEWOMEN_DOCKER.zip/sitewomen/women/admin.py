from django.contrib import admin, messages
from django.utils.safestring import mark_safe

from .models import Women, Category
from django.db.models.functions import Length


admin.site.site_header = "Панель администрирования"
admin.site.index_title = "Известные женщины мира"


class MerriedFilter(admin.SimpleListFilter):
    title = "Статус женщины"
    parameter_name = "status"

    def lookups(self, request, model_admin):
        return [
            ("married", "Замужем"),
            ("single", "Не замужем")
        ]

    def queryset(self, request, queryset):
        if self.value() == "married":
            return queryset.filter(husband__isnull=False)
        elif self.value() == "single":
            return queryset.filter(husband__isnull=True)


@admin.register(Women)
class WomenAdmin(admin.ModelAdmin):
    fields = ("title", "slug", "content", "photo", "post_photo", "cat", "husband", "tags")  # доступные для редактирования поля (в выбранной конкретной записи)
    # exclude = ("tags", "is_published")  # для редактирования будут доступны все поля кроме этих
    readonly_fields = ("post_photo", )  # поля, доступные только для чтения
    prepopulated_fields = {"slug": ("title", )}
    filter_horizontal = ("tags", )  # для 2х колонок при редактировании полей many-to-many
    list_display = ("title", "post_photo", "time_create", "is_published", "cat")  # отображаемые поля
    list_display_links = ("title", )  # кликабельные поля
    ordering = ("time_create", "title")  # по этим полям сортируются записи в АП (не в БД!)
    list_editable = ("is_published", )  # редактируемые поля
    list_per_page = 6  # количество отображаемых записей на странице (пагинация)
    actions = ("set_published", "set_draft")  # пользовательские действия
    search_fields = ("title", "cat__name")  # по этим полям будет вестись поиск
    list_filter = (MerriedFilter, "cat__name", "is_published")  # доступные фильтры
    save_on_top = True

    @admin.display(description="изображение", ordering=Length("content"))
    def post_photo(self, women: Women):
        if women.photo:
            return mark_safe(f"<img src='{women.photo.url}' width=50>")  # чтобы тэги в строке не экранировались
        return "Без фото"

    @admin.action(description="Опубликовать выбранные записи")
    def set_published(self, request, queryset):
        count = queryset.update(is_published=Women.Status.PUBLISHED)
        self.message_user(request, f"{count} записей было опубликовано")

    @admin.action(description="Снять с публикации выбранные записи")
    def set_draft(self, request, queryset):
        count = queryset.update(is_published=Women.Status.DRAFT)
        self.message_user(request, f"{count} записей было снято с публикации", messages.WARNING)



@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("id", "name")
    list_display_links = ("id", "name")
# admin.site.register(Women, WomenAdmin)
