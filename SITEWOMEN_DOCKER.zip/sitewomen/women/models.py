from django.contrib.auth import get_user_model
from django.core.validators import MinLengthValidator, MaxLengthValidator
from django.db import models
from django.template.defaultfilters import slugify
from django.urls import reverse


class PublishedManager(models.Manager):
    def get_queryset(self):  # стандартное имя для функции кастомного менеджера
        return super().get_queryset().filter(is_published=Women.Status.PUBLISHED)


class Women(models.Model):
    class Status(models.IntegerChoices):
        DRAFT = 0, "Черновик"  # в бд пойдет 0, а в форме будет отображаться "Черновик" (для ясности)
        PUBLISHED = 1, "Опубликовано"


    title = models.CharField(max_length=255, verbose_name="Заголовок")  # для кротких текстов (до 255 символов)
    slug = models.SlugField(max_length=255, unique=True, db_index=True, verbose_name="Слаг",
                            validators=[
                                MinLengthValidator(5, message="Минимум 5 символов"),
                                MaxLengthValidator(255, message="Максимум 255 символов")
                            ]
                            )
    photo = models.ImageField(upload_to="photos/%Y/%m/%d", default=None,
                              blank=True, null=True, verbose_name="Фото")
    content = models.TextField(blank=True, verbose_name="Содержимое статьи")  # для больших текстов
    time_create = models.DateTimeField(auto_now_add=True, verbose_name="Время создания")  # обновляется только в момент создания
    time_update = models.DateTimeField(auto_now=True, verbose_name="Время редактирования")  # обновляется в момент внесения изменений
    is_published = models.IntegerField(choices=Status.choices, default=0, verbose_name="Статус")
    cat = models.ForeignKey("Category", on_delete=models.PROTECT, related_name="posts", verbose_name="Категория")
    tags = models.ManyToManyField("TagPost", blank=True, related_name="tags", verbose_name="Тэги")
    husband = models.OneToOneField("Husband", on_delete=models.SET_NULL, null=True, blank=True, related_name="wife",
                                   verbose_name="Муж")
    author = models.ForeignKey(get_user_model(), on_delete=models.SET_NULL, null=True, default=None,
                               related_name="posts", verbose_name="Автор")

    objects = models.Manager()
    published = PublishedManager()

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "Известные женщины"
        verbose_name_plural = "Известные женщины"
        ordering = ["-time_create"]  # по умолчанию будет отсортировано по времени создания (начиная с самого последнего за счет "-")
        indexes = [
            models.Index(fields=["-time_create"])
        ]

    def get_absolute_url(self):
        return reverse("post", kwargs={"post_slug": self.slug})

    # def save(self, *args, **kwargs):
    #     self.slug = slugify(self.title)
    #     super().save(*args, **kwargs)


class Category(models.Model):
    name = models.CharField(max_length=100, db_index=True, verbose_name="Категория")
    slug = models.SlugField(max_length=255, unique=True)

    class Meta:
        verbose_name = "Категория"
        verbose_name_plural = "Категории"

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("category", kwargs={"cat_slug": self.slug})


class TagPost(models.Model):
    tag = models.CharField(max_length=100, db_index=True)
    slug = models.SlugField(max_length=255, unique=True)

    def __str__(self):
        return self.tag

    def get_absolute_url(self):
        return reverse("tag", kwargs={"tag_slug": self.slug})


class Husband(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField(null=True)
    m_count = models.IntegerField(blank=True, default=0)

    def __str__(self):
        return self.name


class UploadModel(models.Model):
    file = models.FileField(upload_to="uploads_model")  # uploads_model - каталог куда быдут файлы сохраняться