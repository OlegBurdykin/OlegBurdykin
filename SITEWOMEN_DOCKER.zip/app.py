from math import sqrt

def get_primes_up_to(n:int):
    is_prime = [True]*(n+1)
    is_prime[0] = False
    is_prime[1] = False

    for num in range(2, int(sqrt(n))+1):
        if is_prime[num]:
            for i in range(num+num, n+1, num):
                is_prime[i] = False
        
    primes = [i for i in range(n+1) if is_prime[i]]
    return primes

print(get_primes_up_to(102))